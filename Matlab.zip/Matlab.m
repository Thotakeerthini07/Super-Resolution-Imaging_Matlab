% Set paths to LR and HR images
lr_path = 'C:\Users\sango\Desktop\lr'; % Path to low-resolution images
hr_path = 'C:\Users\sango\Desktop\hr'; % Path to high-resolution images
% Get list of all image files
lr_files = dir(fullfile(lr_path, '*.jpg'));
hr_files = dir(fullfile(hr_path, '*.jpg'));
% Check that the number of LR and HR images matches(cond,msg)
assert(length(lr_files) == length(hr_files), 'Mismatch between LR and HR images!');
% Get total number of images
num_images = length(lr_files);
% Generate a random permutation
rng(0); % For reproducibility
indices = randperm(num_images);
% Define split ratios
train_ratio = 0.7;
val_ratio = 0.2;
test_ratio = 0.1;
% Compute number of images in each split
num_train = floor(train_ratio * num_images);
num_val = floor(val_ratio * num_images);
num_test = num_images - num_train - num_val;
% Split indices
train_indices = indices(1:num_train);
val_indices = indices(num_train+1:num_train+num_val);
test_indices = indices(num_train+num_val+1:end);
% Initialize cell arrays to store image pairs
train_data = {};
val_data = {};
test_data = {};
% Training data
for i = 1:num_train
    lr_image = imread(fullfile(lr_path, lr_files(train_indices(i)).name));
    hr_image = imread(fullfile(hr_path, hr_files(train_indices(i)).name));
    train_data{end+1} = {lr_image, hr_image};
end
% Validation data
for i = 1:num_val
    lr_image = imread(fullfile(lr_path, lr_files(val_indices(i)).name));
    hr_image = imread(fullfile(hr_path, hr_files(val_indices(i)).name));
    val_data{end+1} = {lr_image, hr_image};
end
% Test data
for i = 1:num_test
    lr_image = imread(fullfile(lr_path, lr_files(test_indices(i)).name));
    hr_image = imread(fullfile(hr_path, hr_files(test_indices(i)).name));
    test_data{end+1} = {lr_image, hr_image};
end
% Save splits to .mat files
save('train_data.mat', 'train_data');
save('val_data.mat', 'val_data');
save('test_data.mat', 'test_data');
disp(['Training set: ', num2str(length(train_data)), ' images']);
disp(['Validation set: ', num2str(length(val_data)), ' images']);
disp(['Test set: ', num2str(length(test_data)), ' images']);
% Load training dataset
load('train_data.mat');
% Preprocess training data
num_samples = length(train_data);
lr_images = [];
hr_images = [];
for i = 1:num_samples
    [lr, hr] = preprocess(train_data{i}{1}, train_data{i}{2});
    lr_images(:,:,:,i) = lr; % Store LR images in a 4D array
    hr_images(:,:,:,i) = hr; % Store HR images in a 4D array
end
% Define the super-resolution model architecture
layers = [
    imageInputLayer([128, 128, 3], 'Name', 'input') % Input size: 128x128x3 (RGB)
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv1')
    reluLayer('Name', 'relu1')
    convolution2dLayer(3, 64, 'Padding', 'same', 'Name', 'conv2')
    reluLayer('Name', 'relu2')
    convolution2dLayer(3, 3, 'Padding', 'same', 'Name', 'conv3') % 3 output channels (RGB)
    regressionLayer('Name', 'output') % For pixel-wise regression
];
% Define training options
options = trainingOptions('adam', ... % Optimizer
    'InitialLearnRate', 1e-4, ...
    'MaxEpochs', 50, ... % Number of epochs
    'MiniBatchSize', 16, ... % Batch size
    'Shuffle', 'every-epoch', ...
    'Verbose', true, ...
    'Plots', 'training-progress'); % Plot training progress
% Train the network
net = trainNetwork(lr_images, hr_images, layers, options);
% Save the trained model
save('super_resolution_model.mat', 'net');
% Load and preprocess test data
load('test_data.mat');
% Preprocess test data
num_samples = length(test_data);
test_lr_images = [];
test_hr_images = [];
for i = 1:num_samples
    [lr, hr] = preprocess(test_data{i}{1}, test_data{i}{2});
    test_lr_images(:,:,:,i) = lr; % Store LR images in a 4D array
    test_hr_images(:,:,:,i) = hr; % Store HR images in a 4D array
end
% Predict high-resolution images for test data
predicted_test_hr_images = predict(net, test_lr_images);
% Compute Mean Squared Error (MSE)
test_mse = mean((test_hr_images(:) - predicted_test_hr_images(:)).^2);
disp(['Test MSE: ', num2str(test_mse)]);
% Compute Peak Signal-to-Noise Ratio (PSNR)
max_pixel_value = 1.0; % Assuming the images are normalized to [0, 1]
test_psnr = 20 * log10(max_pixel_value / sqrt(test_mse));
disp(['Test PSNR: ', num2str(test_psnr), ' dB']);
% Visualize some test results
for i = 1:min(5, num_samples) % Visualize first 5 test samples
    figure;
    subplot(1, 3, 1); imshow(test_lr_images(:,:,:,i)); title('Low-Resolution');
    subplot(1, 3, 2); imshow(test_hr_images(:,:,:,i)); title('High-Resolution (Ground Truth)');
    subplot(1, 3, 3); imshow(predicted_test_hr_images(:,:,:,i)); title('Predicted High-Resolution');
end
% Preprocessing function
function [lr_processed, hr_processed] = preprocess(lr_image, hr_image)
    % Normalize images to [0, 1]
    lr_processed = im2double(lr_image);
    hr_processed = im2double(hr_image);
    % Resize to consistent dimensions (optional)
    target_size = [128, 128]; % Example size
    lr_processed = imresize(lr_processed, target_size);
    hr_processed = imresize(hr_processed, target_size);
end
